<!--
Thanks for reporting issues back to tmi.js!
This is the issue tracker of tmi.js, please use the "Twitch API" Discord "#tmi"
channel for support questions. Check the README "Community" section for links.
-->

**Actual behaviour:**


**Expected behaviour:**


**Error log:**

```
Insert your error log here
```

**Configuration**
- tmi.js version:
- Node version (if applicable):
- Browser and version (if applicable):
- Operating system:
