const Client = require('./lib/Client');
module.exports = {
	client: Client,
	Client
};
